package com.flightpriceanalysis.flightpriceanalysis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlightpriceanalysisApplicationTests {

	@Test
	void contextLoads() {
	}

}
