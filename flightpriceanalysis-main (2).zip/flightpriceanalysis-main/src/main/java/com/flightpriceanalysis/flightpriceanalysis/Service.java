package com.flightpriceanalysis.flightpriceanalysis;


public class Service {
}





